"""ClipForge local server. Run: python3 server.py   then open http://127.0.0.1:8000
No pip installs needed (Python 3.10+ and ffmpeg only)."""
import json, os, re, subprocess, threading, time, uuid, zipfile, urllib.request, urllib.error
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse, parse_qs
from clipforge.models import segments_from_json, Clip
from clipforge.highlights import validate_highlights, fallback_select
from clipforge.boundaries import snap_clip
from clipforge.captions import build_ass, CaptionStyle
from clipforge.render import render_clip, RenderOptions
from clipforge.probe import probe, validate_output

ROOT = Path(__file__).parent


def load_env_file(path: Path) -> None:
    """Load simple KEY=value entries without overriding existing environment values."""
    if not path.is_file():
        return
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip().strip("\"").strip("'")
        if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", key):
            os.environ.setdefault(key, value)


load_env_file(ROOT / ".env")
DATA = ROOT / "data"; DATA.mkdir(exist_ok=True)
MAX_MB = int(os.environ.get("CLIPFORGE_MAX_UPLOAD_MB", "1500"))
MAX_MIN = int(os.environ.get("CLIPFORGE_MAX_MINUTES", "90"))
FONT = os.environ.get("CLIPFORGE_FONT", "Noto Sans Malayalam")
LLM_MODEL = os.environ.get("CLIPFORGE_LLM_MODEL", "claude-sonnet-5-5")
EXT = {".mp4", ".mov", ".mkv", ".webm"}
STYLES = {"Dynamic captions": CaptionStyle(), "Clean professional": CaptionStyle(size=60, active="#4DB6FF", margin_v=480),
          "Podcast style": CaptionStyle(size=64, active="#B79BFF", margin_v=420)}
LANG = {"Malayalam + English": "ml", "English": "en", "Hindi": "hi", "Original language": None}
JOBS: dict[str, dict] = {}
STAGES = ["Validating source", "Extracting audio", "Transcribing speech", "Detecting highlights",
          "Selecting clip boundaries", "Rendering clips", "Saving and validating outputs"]


class Cancelled(Exception): ...


def save(job):
    (DATA / job["id"] / "job.json").write_text(json.dumps(job, ensure_ascii=False))


def http_json(url, headers, body, timeout=600):
    req = urllib.request.Request(url, data=body, headers=headers, method="POST")
    try:
        return json.loads(urllib.request.urlopen(req, timeout=timeout).read())
    except urllib.error.HTTPError as e:
        raise RuntimeError(f"{url.split('/')[2]} returned {e.code}: {e.read().decode('utf-8', 'ignore')[:300]}")


def transcribe(audio: Path, lang):
    b = uuid.uuid4().hex
    fields = [("model", "whisper-1"), ("response_format", "verbose_json"),
              ("timestamp_granularities[]", "word"), ("timestamp_granularities[]", "segment")]
    if lang: fields.append(("language", lang))
    body = b"".join(f'--{b}\r\nContent-Disposition: form-data; name="{k}"\r\n\r\n{v}\r\n'.encode() for k, v in fields)
    body += (f'--{b}\r\nContent-Disposition: form-data; name="file"; filename="a.mp3"\r\nContent-Type: audio/mpeg\r\n\r\n').encode()
    body += audio.read_bytes() + f"\r\n--{b}--\r\n".encode()
    r = http_json("https://api.openai.com/v1/audio/transcriptions",
                  {"Authorization": "Bearer " + os.environ["OPENAI_API_KEY"], "Content-Type": f"multipart/form-data; boundary={b}"}, body)
    words = r.get("words", [])
    segs = []
    for s in r.get("segments", []):
        ws = [{"text": w["word"].strip(), "start": w["start"], "end": w["end"]} for w in words
              if s["start"] <= (w["start"] + w["end"]) / 2 <= s["end"] and w["end"] > w["start"]]
        if s["end"] > s["start"] and s["text"].strip():
            segs.append({"text": s["text"].strip(), "start": s["start"], "end": s["end"], "words": ws})
    if not segs: raise RuntimeError("No speech was detected in this video.")
    return segments_from_json(segs)


def llm_highlights(segments, count, lo, hi, dur):
    tx = "\n".join(f"[{s.start:.1f}-{s.end:.1f}] {s.text}" for s in segments)[:150000]
    prompt = (f"Pick up to {count} distinct, non-overlapping moments from this timestamped transcript for short vertical videos, "
              f"each {lo}-{hi} seconds, with a strong opening hook, standalone context and a natural ending. Use only times that exist "
              f"(0-{dur:.0f}s). Never invent speech. Reply with ONLY a JSON list; each item: title, start, end, hook_summary, takeaway, "
              f"rationale, language, quality_score (0-10), opening_caption.\n\nTranscript:\n{tx}")
    r = http_json("https://api.anthropic.com/v1/messages",
                  {"x-api-key": os.environ["ANTHROPIC_API_KEY"], "anthropic-version": "2023-06-01", "content-type": "application/json"},
                  json.dumps({"model": LLM_MODEL, "max_tokens": 4000, "messages": [{"role": "user", "content": prompt}]}).encode())
    return "".join(b.get("text", "") for b in r["content"])


def run(job, src: Path, p):
    d = DATA / job["id"]
    def stage(name, i):
        if job["cancel"]: raise Cancelled()
        job["stage"], job["step"] = name, i; save(job)
    try:
        job["status"] = "running"
        stage(STAGES[0], 0)
        info = probe(src)
        if not info.width or not info.has_audio: raise RuntimeError("The video needs both a picture and an audio track.")
        if info.duration > MAX_MIN * 60: raise RuntimeError(f"Video is {info.duration/60:.0f} min; the limit is {MAX_MIN} min.")
        stage(STAGES[1], 1)
        audio = d / "audio.mp3"
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", str(src), "-vn", "-ac", "1", "-ar", "16000", "-b:a", "32k", str(audio)], check=True, timeout=1800)
        if audio.stat().st_size > 24_000_000: raise RuntimeError("Audio is over the 25 MB transcription limit. Use a shorter video.")
        stage(STAGES[2], 2)
        segs = transcribe(audio, p["lang"])
        job["transcript_segments"] = len(segs)
        stage(STAGES[3], 3)
        lo, hi, n = p["min"], p["max"], p["count"]
        clips, note = [], ""
        if os.environ.get("ANTHROPIC_API_KEY"):
            try:
                clips, rej = validate_highlights(llm_highlights(segs, n, lo, hi, info.duration), info.duration, lo, hi)
                clips = clips[:n]
            except Exception as e:
                note = f"AI selection failed ({str(e)[:120]}); used basic selection. "
        else:
            note = "AI selection key not set; used basic selection by speech density. "
        if not clips: clips = fallback_select(segs, n, lo, hi)
        if not clips: raise RuntimeError("Could not find any suitable clip in this video's speech.")
        if len(clips) < n: note += f"Only {len(clips)} suitable clips found. "
        stage(STAGES[4], 4)
        clips = sorted((snap_clip(c, segs, info.duration, hi) for c in clips), key=lambda c: c.start)
        out = []
        for i, c in enumerate(clips, 1):
            stage(f"Rendering clip {i} of {len(clips)}", 5)
            ass = d / f"c{i}.ass"
            st = STYLES.get(p["style"], CaptionStyle())
            ass.write_text(build_ass(segs, c.start, c.end, CaptionStyle(**{**st.__dict__, "font": FONT})), encoding="utf-8")
            mp4 = d / f"clip{i}.mp4"
            render_clip(str(src), str(mp4), c, RenderOptions(), str(ass), str(ROOT / "fonts"))
            problems = validate_output(mp4, lo, hi)
            subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-ss", "1", "-i", str(mp4), "-frames:v", "1", "-vf", "scale=360:-1", str(d / f"thumb{i}.jpg")], timeout=60)
            out.append({"n": i, "title": c.title, "start": c.start, "end": c.end, "duration": round(c.duration, 1),
                        "reason": c.rationale or c.hook_summary, "file": mp4.name, "thumb": f"thumb{i}.jpg", "problems": problems})
        stage(STAGES[6], 6)
        with zipfile.ZipFile(d / "clips.zip", "w") as z:
            for c in out:
                if not c["problems"]: z.write(d / c["file"], c["file"])
        job.update(clips=out, note=note.strip(), status="done", stage="Done")
    except Cancelled:
        job.update(status="cancelled", stage="Cancelled")
    except Exception as e:
        job.update(status="failed", error=str(e)[:500])
    finally:
        for f in d.glob("audio.mp3"): f.unlink(missing_ok=True)
        save(job)


class H(BaseHTTPRequestHandler):
    def _authorized(self):
        user = os.environ.get("CLIPFORGE_AUTH_USER", "")
        password = os.environ.get("CLIPFORGE_AUTH_PASSWORD", "")
        # Auth is required when either credential is configured.
        if not user and not password:
            return True
        import base64
        header = self.headers.get("Authorization", "")
        expected = "Basic " + base64.b64encode(f"{user}:{password}".encode()).decode()
        if header == expected:
            return True
        self.send_response(401)
        self.send_header("WWW-Authenticate", 'Basic realm="ClipForge AI"')
        self.send_header("Content-Length", "0")
        self.end_headers()
        return False

    def do_HEAD(self):
        if not self._authorized():
            return
        self.send_response(200 if self.path == "/" else 404)
        self.end_headers()

    def log_message(self, *a): pass
    def send(self, code, obj):
        b = json.dumps(obj, ensure_ascii=False).encode()
        self.send_response(code); self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)

    def file(self, path: Path, ctype, dl=None):
        if not path.is_file(): return self.send(404, {"error": "Not found"})
        size, start, end, code = path.stat().st_size, 0, path.stat().st_size - 1, 200
        m = re.match(r"bytes=(\d*)-(\d*)", self.headers.get("Range", ""))
        if m and (m.group(1) or m.group(2)):
            start = int(m.group(1) or 0); end = int(m.group(2)) if m.group(2) else end; code = 206
        self.send_response(code); self.send_header("Content-Type", ctype); self.send_header("Accept-Ranges", "bytes")
        self.send_header("Content-Length", str(end - start + 1))
        if code == 206: self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
        if dl: self.send_header("Content-Disposition", f'attachment; filename="{dl}"')
        self.end_headers()
        with open(path, "rb") as f:
            f.seek(start); left = end - start + 1
            while left > 0:
                chunk = f.read(min(1 << 20, left))
                if not chunk: break
                self.wfile.write(chunk); left -= len(chunk)

    def do_GET(self):
        if not self._authorized(): return
        u = urlparse(self.path); parts = u.path.strip("/").split("/")
        if u.path == "/api/config":
            return self.send(200, {"transcription": bool(os.environ.get("OPENAI_API_KEY")),
                                   "ai_selection": bool(os.environ.get("ANTHROPIC_API_KEY")), "max_mb": MAX_MB, "max_minutes": MAX_MIN})
        if parts[0] == "api" and len(parts) == 3 and parts[1] == "jobs":
            j = JOBS.get(parts[2]); return self.send(200, j) if j else self.send(404, {"error": "Unknown job"})
        if parts[0] == "files" and len(parts) == 3 and parts[1] in JOBS and re.fullmatch(r"[\w.]+", parts[2]):
            ct = "video/mp4" if parts[2].endswith(".mp4") else "image/jpeg" if parts[2].endswith(".jpg") else "application/zip"
            return self.file(DATA / parts[1] / parts[2], ct, parts[2] if "dl" in parse_qs(u.query) else None)
        if u.path == "/": return self.file(ROOT / "web" / "index.html", "text/html; charset=utf-8")
        self.send(404, {"error": "Not found"})

    def do_POST(self):
        if not self._authorized(): return
        u = urlparse(self.path); q = {k: v[0] for k, v in parse_qs(u.query).items()}; parts = u.path.strip("/").split("/")
        if len(parts) == 4 and parts[:2] == ["api", "jobs"] and parts[3] == "cancel" and parts[2] in JOBS:
            JOBS[parts[2]]["cancel"] = True; return self.send(200, {"ok": True})
        if u.path != "/api/jobs": return self.send(404, {"error": "Not found"})
        if not os.environ.get("OPENAI_API_KEY"):
            return self.send(400, {"error": "Speech transcription isn't set up. Set OPENAI_API_KEY and restart the server (see README)."})
        ext = Path(q.get("filename", "")).suffix.lower()
        try:
            n = int(self.headers.get("Content-Length", 0))
        except ValueError:
            return self.send(400, {"error": "Invalid upload size."})
        if ext not in EXT: return self.send(400, {"error": "Use an MP4, MOV, MKV or WebM file."})
        if n <= 0 or n > MAX_MB * 1024 * 1024: return self.send(400, {"error": f"File must be under {MAX_MB} MB."})
        try:
            count = min(max(int(q.get("count", 5)), 1), 10)
            lo, hi = int(q.get("min", 30)), int(q.get("max", 60))
            if not (5 <= lo < hi <= 90):
                raise ValueError("Clip length must be between 5 and 90 seconds.")
            p = {"count": count, "min": lo, "max": hi,
                 "lang": LANG.get(q.get("lang", ""), None), "style": q.get("style", "")}
        except ValueError as e:
            return self.send(400, {"error": str(e) or "Invalid settings."})
        jid = uuid.uuid4().hex[:12]; d = DATA / jid; d.mkdir(); src = d / f"source{ext}"
        with open(src, "wb") as f:
            left = n
            while left > 0:
                chunk = self.rfile.read(min(1 << 20, left))
                if not chunk: break
                f.write(chunk); left -= len(chunk)
        job = {"id": jid, "status": "queued", "stage": "Queued", "step": -1, "total_steps": len(STAGES), "cancel": False, "clips": [], "error": "", "note": ""}
        JOBS[jid] = job; save(job)
        threading.Thread(target=run, args=(job, src, p), daemon=True).start()
        self.send(200, {"id": jid})


if __name__ == "__main__":
    host = os.environ.get("CLIPFORGE_HOST", "127.0.0.1")
    port = int(os.environ.get("PORT", os.environ.get("CLIPFORGE_PORT", "8000")))
    print(f"ClipForge running at http://{host}:{port}  (Ctrl+C to stop)")
    print("Transcription key:", "set" if os.environ.get("OPENAI_API_KEY") else "MISSING (OPENAI_API_KEY)",
          "| AI selection key:", "set" if os.environ.get("ANTHROPIC_API_KEY") else "not set (basic selection)")
    ThreadingHTTPServer((host, port), H).serve_forever()
