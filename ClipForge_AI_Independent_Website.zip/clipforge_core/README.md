# ClipForge AI — independent, self-hosted video studio

ClipForge is your own browser-based video editing website. It does not use Higgsfield or a generative-video API. FFmpeg renders vertical clips and captions; speech-to-text uses the OpenAI API, and Anthropic is optional for smarter highlight selection.

**For cloud hosting and your own custom domain, follow [`DEPLOY_YOUR_OWN_DOMAIN.md`](DEPLOY_YOUR_OWN_DOMAIN.md).** It includes Docker, HTTPS via Caddy, persistent storage, and owner-only Basic Auth setup.

# ClipForge AI — browser-based short-video studio

ClipForge runs a private web interface on your own computer. Open it in Chrome, Safari, Edge, or Firefox to turn a video you own into short, vertical MP4 clips with word-by-word captions, including Malayalam.

## Quick start

### Windows
1. Install **Python 3.10+** and **FFmpeg**. Make sure `python` and `ffmpeg` work from Command Prompt.
2. Double-click `start_clipforge.bat`. On the first run it creates `.env` and opens it in Notepad.
3. Add your OpenAI API key to the blank value in `.env`:
   `OPENAI_API_KEY=your_key_here`
4. Save `.env`, double-click `start_clipforge.bat` again, and open **http://127.0.0.1:8000** if it does not open automatically.

### macOS / Linux
1. Install **Python 3.10+** and **FFmpeg**.
2. In Terminal, enter the project folder and run `./start_clipforge.sh`.
3. On first run, add your key to the generated `.env` file:
   `OPENAI_API_KEY=your_key_here`
4. Run `./start_clipforge.sh` again. Visit **http://127.0.0.1:8000**.

No Python packages need to be installed. The app uses Python's standard library plus FFmpeg.

## API keys and costs

- **OpenAI API key is required** for Whisper speech-to-text. API usage is billed by OpenAI; a ChatGPT subscription does not include API credits.
- **Anthropic API key is optional**. When configured, it selects moments using the transcript. Without it, ClipForge uses its built-in speech-density selector.
- Keep `.env` private. Never share it or upload it publicly.

## Create clips

1. Upload an MP4, MOV, MKV, or WebM video you own or have permission to edit.
2. Choose the clip count, duration range, caption language, and caption style.
3. Confirm your rights to use the source video and press **Start processing**.
4. Wait while ClipForge transcribes the audio, selects highlights, renders vertical clips, and validates the outputs.
5. Preview each clip and download individual MP4s or the ZIP archive.

## Privacy and limits

- The server binds to `127.0.0.1` (your own computer), not a public network interface.
- Source videos and finished clips are stored in the local `data/` directory.
- Audio extracted from the video is sent to OpenAI for transcription. If you configure Anthropic, the transcript is sent there for highlight selection.
- YouTube links are validated only; videos are not downloaded automatically.
- Default upload limit: 1500 MB. Default source duration limit: 90 minutes. These can be adjusted with `CLIPFORGE_MAX_UPLOAD_MB` and `CLIPFORGE_MAX_MINUTES` in `.env`.
- Malayalam captions use the `Noto Sans Malayalam` font family. If glyphs are missing on your system, set `CLIPFORGE_FONT` in `.env` to a suitable installed font.

## Tests

Run core logic tests (fast):

```bash
python3 -m unittest clipforge.tests.test_core -k test_valid_and_rejections
```

The suite also includes a real FFmpeg rendering test and a full server pipeline test. Those tests create and render synthetic videos and may take several minutes. The full server test substitutes transcription only within the test process; normal use still calls the configured API.

## Troubleshooting

- **Transcription key missing:** verify `OPENAI_API_KEY` in `.env`, save it, and restart the server.
- **FFmpeg not found:** install FFmpeg and add its `bin` folder to PATH.
- **Malayalam appears as squares:** install Noto Sans Malayalam and set `CLIPFORGE_FONT` if needed.
- **Port 8000 is busy:** close the other local service or stop it before starting ClipForge.
- **Stop ClipForge:** press `Ctrl+C` in the terminal window running the server.
