# ClipForge AI — your independent website

This project package contains the existing ClipForge core plus cloud deployment files for your own VPS/domain. No Higgsfield platform or community feed is used.

**Start here:** `DEPLOY_YOUR_OWN_DOMAIN.md`

The site is currently an owner-operated studio, not a public multi-user SaaS. It includes owner-only Basic Auth for private hosting. Do not open public sign-ups until multi-user authentication, storage isolation, job persistence, quotas, and operational monitoring are implemented.
