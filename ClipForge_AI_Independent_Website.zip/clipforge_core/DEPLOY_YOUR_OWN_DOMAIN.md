# Deploy ClipForge AI on your own server and domain

This is a standalone, self-hostable ClipForge AI project. It does not use Higgsfield, a community feed, or a generative-video API. FFmpeg performs clip rendering and caption burn-in. OpenAI speech-to-text is used for transcription; Anthropic is optional for AI-assisted highlight selection.

## What you need
- A Linux VPS (Ubuntu 22.04/24.04 recommended) with Docker Engine and Docker Compose plugin.
- A domain or subdomain you own.
- DNS access to create an `A` record pointing the domain to your VPS IPv4 address (and an `AAAA` record only if IPv6 is configured).
- An OpenAI API key for transcription. ChatGPT subscription is not an API key; API usage is billed separately.
- At least 2 vCPU and 4 GB RAM to start; more disk space and RAM are recommended for large videos.

## Deploy
1. Copy this folder to your VPS, or upload the ZIP and extract it.
2. Install Docker Engine and the Docker Compose plugin using the official instructions for your Linux distribution.
3. In this folder, run `cp .env.example .env` and edit `.env`.
4. Set `DOMAIN` to your real domain/subdomain, `OPENAI_API_KEY` to your API key, and set a strong `CLIPFORGE_AUTH_PASSWORD`. Do not commit or share `.env`.
5. In your DNS provider, point the domain's `A` record to the VPS public IP. Allow inbound TCP ports 80 and 443 in the VPS firewall.
6. Start the site: `docker compose up -d --build`
7. Check logs: `docker compose logs -f clipforge` and `docker compose logs -f caddy`.
8. Open `https://YOUR_DOMAIN`. Caddy automatically requests and renews a TLS certificate when DNS and ports are correct. Your browser will ask for the Basic Auth username/password configured in `.env`.

## Updating
- Back up your video data first.
- Replace the project files with the updated version, preserving `.env`.
- Run `docker compose up -d --build`.

## Backups and storage
- Source videos and rendered files are stored in the persistent Docker volume `clipforge_data`.
- Back up the volume regularly. Videos may be large; budget disk space accordingly.
- Never expose port 8000 directly to the internet; Caddy is the public entry point.
- Keep authentication enabled. Basic Auth is a simple owner-only gate, not a multi-user account system.
- For a public multi-user SaaS, add proper accounts, per-user storage isolation, quotas, job queueing, and stronger authorization before opening registration.

## Current app behavior and limits
- Uploads MP4, MOV, MKV, and WebM.
- Generates vertical short clips with captions and individual/ZIP downloads.
- Speech transcription requires `OPENAI_API_KEY`; no generative-video API is used.
- Optional `ANTHROPIC_API_KEY` improves highlight selection. If omitted, built-in selection is used.
- This current core is designed as a private owner-operated studio. It is not yet a multi-user SaaS and its job list is held in process memory; keep one app instance and use it for private use until persistent jobs and multi-user accounts are added.
