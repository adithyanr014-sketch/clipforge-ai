#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if ! command -v python3 >/dev/null 2>&1; then echo "Python 3.10+ is required."; exit 1; fi
if ! command -v ffmpeg >/dev/null 2>&1; then echo "FFmpeg is required. Install it with your OS package manager."; exit 1; fi
if [[ ! -f .env ]]; then
  cp .env.example .env
  echo "Created .env. Add your OPENAI_API_KEY, then run this script again."
  if command -v open >/dev/null 2>&1; then open -t .env; elif command -v xdg-open >/dev/null 2>&1; then xdg-open .env >/dev/null 2>&1 || true; fi
  exit 0
fi
URL="http://127.0.0.1:8000"
if command -v open >/dev/null 2>&1; then (sleep 2; open "$URL") >/dev/null 2>&1 & elif command -v xdg-open >/dev/null 2>&1; then (sleep 2; xdg-open "$URL") >/dev/null 2>&1 & fi
exec python3 server.py
