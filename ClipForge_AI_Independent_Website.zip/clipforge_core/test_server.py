"""End-to-end test of server + pipeline with REAL ffmpeg. Only the paid transcription call is replaced (test only)."""
import json, os, subprocess, threading, time, urllib.request, tempfile
os.environ["OPENAI_API_KEY"] = "test"; os.environ["CLIPFORGE_FONT"] = "FreeSans"
import server
from clipforge.models import segments_from_json
server.transcribe = lambda a, l: segments_from_json([{"text": f"Sentence {i} ഇത് ഒരു പരീക്ഷണം.", "start": i*6.0, "end": i*6.0+5.5,
    "words": [{"text": t, "start": i*6.0+j*.8, "end": i*6.0+j*.8+.7} for j, t in enumerate(f"Sentence {i} ഇത് ഒരു പരീക്ഷണം".split())]} for i in range(30)])
threading.Thread(target=lambda: server.ThreadingHTTPServer(("127.0.0.1", 8123), server.H).serve_forever(), daemon=True).start()
d = tempfile.mkdtemp(); src = d + "/s.mp4"
subprocess.run(["ffmpeg","-y","-loglevel","error","-f","lavfi","-i","testsrc2=size=1280x720:rate=30:duration=180","-f","lavfi","-i","sine=duration=180","-c:v","libx264","-preset","ultrafast","-c:a","aac","-shortest",src],check=True)
req = urllib.request.Request("http://127.0.0.1:8123/api/jobs?filename=s.mp4&count=3&min=30&max=60&lang=Malayalam%20%2B%20English&style=Dynamic%20captions", data=open(src,"rb").read(), method="POST")
jid = json.load(urllib.request.urlopen(req))["id"]
while True:
    j = json.load(urllib.request.urlopen(f"http://127.0.0.1:8123/api/jobs/{jid}"))
    if j["status"] in ("done", "failed"): break
    time.sleep(1)
print(j["status"], j["error"], j["note"]); [print(c["file"], c["duration"], c["problems"]) for c in j["clips"]]
z = urllib.request.urlopen(f"http://127.0.0.1:8123/files/{jid}/clips.zip").read(); print("zip bytes", len(z))
assert j["status"] == "done" and len(j["clips"]) == 3 and all(not c["problems"] for c in j["clips"])
print("PASS")
