"""ClipForge core pipeline: highlight validation, boundary snapping, ASS captions, FFmpeg render, output validation."""
