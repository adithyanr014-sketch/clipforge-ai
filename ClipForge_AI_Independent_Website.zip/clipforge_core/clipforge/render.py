"""Build and run the FFmpeg command for one 1080x1920 clip. No shell, no stretching."""
from __future__ import annotations
import subprocess
from dataclasses import dataclass
from pathlib import Path
from .models import Clip
from .probe import probe

W, H = 1080, 1920


@dataclass
class RenderOptions:
    layout: str = "crop"          # "crop" (tracked crop) or "blur" (fit + blurred background)
    crop_center_x: float = 0.5    # 0..1 horizontal subject position from tracker; 0.5 = centered fallback
    crf: int = 18
    preset: str = "medium"
    fps: int = 30
    loudnorm: bool = True


def _esc_filter_path(p: str) -> str:
    return p.replace("\\", "/").replace(":", r"\:").replace("'", r"\'").replace(",", r"\,").replace("[", r"\[").replace("]", r"\]")


def build_filter(src_w: int, src_h: int, opts: RenderOptions, ass_path: str | None, fonts_dir: str | None) -> str:
    if opts.layout == "blur":
        fg = f"[0:v]scale={W}:-2:force_original_aspect_ratio=decrease[fg]"
        bg = f"[0:v]scale=-2:{H}:force_original_aspect_ratio=increase,crop={W}:{H},boxblur=30:5[bg]"
        chain = f"{bg};{fg};[bg][fg]overlay=(W-w)/2:(H-h)/2,setsar=1[v0]"
    else:
        scale = max(W / src_w, H / src_h)           # cover, preserving aspect ratio
        sw, sh = round(src_w * scale / 2) * 2, round(src_h * scale / 2) * 2
        sw, sh = max(sw, W), max(sh, H)
        x = int(min(max(opts.crop_center_x * sw - W / 2, 0), sw - W))
        y = (sh - H) // 2
        chain = f"[0:v]scale={sw}:{sh},crop={W}:{H}:{x}:{y},setsar=1[v0]"
    if ass_path:
        sub = f"ass='{_esc_filter_path(ass_path)}'" + (f":fontsdir='{_esc_filter_path(fonts_dir)}'" if fonts_dir else "")
        chain += f";[v0]{sub}[v]"
    else:
        chain += ";[v0]null[v]"
    return chain


def build_command(src: str, out: str, clip: Clip, src_w: int, src_h: int, opts: RenderOptions,
                  ass_path: str | None = None, fonts_dir: str | None = None) -> list[str]:
    cmd = ["ffmpeg", "-y", "-hide_banner", "-loglevel", "error", "-ss", f"{clip.start:.3f}", "-t", f"{clip.duration:.3f}",
           "-i", src, "-filter_complex", build_filter(src_w, src_h, opts, ass_path, fonts_dir), "-map", "[v]", "-map", "0:a:0?"]
    if opts.loudnorm:
        cmd += ["-af", "loudnorm=I=-16:TP=-1.5:LRA=11"]
    cmd += ["-r", str(opts.fps), "-c:v", "libx264", "-preset", opts.preset, "-crf", str(opts.crf), "-pix_fmt", "yuv420p",
            "-c:a", "aac", "-b:a", "192k", "-ar", "48000", "-movflags", "+faststart", out]
    return cmd


def render_clip(src: str, out: str, clip: Clip, opts: RenderOptions | None = None, ass_path: str | None = None,
                fonts_dir: str | None = None, timeout: int = 1800) -> Path:
    opts = opts or RenderOptions()
    info = probe(src)
    if not info.width or not info.height:
        raise ValueError("Source has no video stream")
    if clip.end > info.duration + 0.5:
        raise ValueError("Clip exceeds source duration")
    Path(out).parent.mkdir(parents=True, exist_ok=True)
    cmd = build_command(src, out, clip, info.width, info.height, opts, ass_path, fonts_dir)
    p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    if p.returncode != 0:
        raise RuntimeError(f"ffmpeg failed: {p.stderr.strip()[-800:]}")
    return Path(out)
