"""ASS caption generation with word-by-word karaoke highlight. libass (HarfBuzz) handles Malayalam shaping;
the font must contain Malayalam glyphs (bundle Noto Sans Malayalam, OFL, in ./fonts)."""
from __future__ import annotations
from dataclasses import dataclass
from .models import Segment, Word


@dataclass
class CaptionStyle:
    font: str = "Noto Sans Malayalam"
    size: int = 72
    active: str = "#FFD400"     # highlighted (already-spoken) word
    inactive: str = "#FFFFFF"
    outline: str = "#000000"
    outline_px: int = 5
    shadow_px: int = 2
    margin_v: int = 520         # px from bottom; keeps clear of platform UI (~ bottom 20-25%)
    max_chars: int = 22
    max_words: int = 4


def _bgr(hex_color: str, alpha: int = 0) -> str:
    h = hex_color.lstrip("#")
    r, g, b = h[0:2], h[2:4], h[4:6]
    return f"&H{alpha:02X}{b}{g}{r}".upper()


def _ts(t: float) -> str:
    t = max(0.0, t)
    cs = round(t * 100)
    h, rem = divmod(cs, 360000)
    m, rem = divmod(rem, 6000)
    s, c = divmod(rem, 100)
    return f"{h}:{m:02d}:{s:02d}.{c:02d}"


def _esc(text: str) -> str:
    return text.replace("\\", "\\\\").replace("{", "(").replace("}", ")").replace("\n", " ")


def _group(words: list[Word], st: CaptionStyle) -> list[list[Word]]:
    groups, cur = [], []
    for w in words:
        if cur and (len(cur) >= st.max_words or sum(len(x.text) + 1 for x in cur) + len(w.text) > st.max_chars):
            groups.append(cur); cur = []
        cur.append(w)
    if cur:
        groups.append(cur)
    return groups


def _wrap(text: str, max_chars: int) -> str:
    lines, cur = [], ""
    for w in text.split():
        if cur and len(cur) + 1 + len(w) > max_chars:
            lines.append(cur); cur = w
        else:
            cur = f"{cur} {w}".strip()
    if cur:
        lines.append(cur)
    return "\\N".join(lines)


def build_ass(segments: list[Segment], clip_start: float, clip_end: float, st: CaptionStyle | None = None,
              width: int = 1080, height: int = 1920) -> str:
    st = st or CaptionStyle()
    header = f"""[Script Info]
ScriptType: v4.00+
PlayResX: {width}
PlayResY: {height}
WrapStyle: 2
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,{st.font},{st.size},{_bgr(st.active)},{_bgr(st.inactive)},{_bgr(st.outline)},&H80000000,-1,0,0,0,100,100,0,0,1,{st.outline_px},{st.shadow_px},2,60,60,{st.margin_v},1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
    events: list[str] = []
    for seg in segments:
        if seg.end <= clip_start or seg.start >= clip_end:
            continue
        if seg.words:
            ws = [Word(w.text, max(w.start, clip_start), min(w.end, clip_end)) for w in seg.words
                  if w.end > clip_start and w.start < clip_end]
            for g in _group(ws, st):
                g_start, g_end = g[0].start, g[-1].end
                parts = []
                for i, w in enumerate(g):
                    nxt = g[i + 1].start if i + 1 < len(g) else w.end
                    dur_cs = max(1, round((max(nxt, w.end) - w.start) * 100))
                    parts.append(f"{{\\kf{dur_cs}}}{_esc(w.text)}")
                events.append(f"Dialogue: 0,{_ts(g_start - clip_start)},{_ts(g_end - clip_start)},Default,,0,0,0,,{' '.join(parts)}")
        else:  # sentence-level fallback when no word timestamps
            s, e = max(seg.start, clip_start), min(seg.end, clip_end)
            if e - s >= 0.1:
                events.append(f"Dialogue: 0,{_ts(s - clip_start)},{_ts(e - clip_start)},Default,,0,0,0,,{_wrap(_esc(seg.text), st.max_chars)}")
    if not events:
        raise ValueError("No caption events fall inside the clip range")
    return header + "\n".join(events) + "\n"


def validate_ass_timing(ass_text: str, clip_duration: float) -> list[str]:
    """Return a list of timing problems (empty = OK)."""
    problems, last_end = [], 0.0
    def parse(t):
        h, m, s = t.split(":"); return int(h) * 3600 + int(m) * 60 + float(s)
    for ln in ass_text.splitlines():
        if ln.startswith("Dialogue:"):
            f = ln.split(",", 9)
            s, e = parse(f[1]), parse(f[2])
            if e <= s: problems.append(f"non-positive event at {f[1]}")
            if e > clip_duration + 0.05: problems.append(f"event ends after clip at {f[2]}")
            last_end = e
    return problems
