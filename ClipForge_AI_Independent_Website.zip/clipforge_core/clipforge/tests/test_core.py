import json, os, subprocess, tempfile, unittest
from pathlib import Path
from clipforge.models import Segment, Word, Clip
from clipforge.highlights import validate_highlights, fallback_select
from clipforge.boundaries import snap_clip
from clipforge.captions import build_ass, CaptionStyle, validate_ass_timing
from clipforge.render import render_clip, RenderOptions
from clipforge.probe import validate_output

ML = "ഇത് ഒരു പരീക്ഷണം ആണ്"  # Malayalam sample
SEGS = [Segment(f"Sentence {i}.", i * 6.0, i * 6.0 + 5.5) for i in range(30)]  # 180s of speech


class Highlights(unittest.TestCase):
    def test_valid_and_rejections(self):
        raw = "```json\n" + json.dumps([
            {"title": "A", "start": 10, "end": 50, "quality_score": 8},
            {"title": "B", "start": 20, "end": 55},           # overlaps A
            {"title": "C", "start": 500, "end": 540},         # beyond source
            {"title": "D", "start": 100, "end": 105},         # too short
            {"title": "E"},                                   # missing fields
        ]) + "\n```"
        ok, bad = validate_highlights(raw, 180)
        self.assertEqual([c.title for c in ok], ["A"])
        self.assertEqual(len(bad), 4)

    def test_invalid_json_raises(self):
        with self.assertRaises(ValueError):
            validate_highlights("not json", 100)

    def test_fallback_distinct_and_in_range(self):
        clips = fallback_select(SEGS, 5)
        self.assertGreaterEqual(len(clips), 3)
        for a, b in zip(clips, clips[1:]):
            self.assertLessEqual(a.end, b.start)
        for c in clips:
            self.assertTrue(30 <= c.duration <= 60 and c.end <= 180)

    def test_fallback_returns_fewer_not_fake(self):
        self.assertEqual(fallback_select(SEGS[:3], 5), [])


class Boundaries(unittest.TestCase):
    def test_snap(self):
        c = snap_clip(Clip("x", 13.0, 52.0), SEGS, 180)
        self.assertAlmostEqual(c.start, 12.0 - 0.15 + 6.0 - 6.0 + 0, delta=6.2)
        self.assertTrue(any(abs(c.end - 0.35 - s.end) < 1e-6 for s in SEGS))
        self.assertLessEqual(c.duration, 61)


class Captions(unittest.TestCase):
    def test_word_karaoke_and_malayalam(self):
        words = tuple(Word(t, 10 + i * 0.5, 10.5 + i * 0.5) for i, t in enumerate(ML.split()))
        seg = Segment(ML, 10, 12.5, words)
        ass = build_ass([seg], 9.0, 20.0)
        self.assertIn("\\kf", ass); self.assertIn("പരീക്ഷണം", ass)
        self.assertEqual(validate_ass_timing(ass, 11.0), [])

    def test_sentence_fallback(self):
        ass = build_ass([Segment("No word timings here at all", 1, 3)], 0, 10)
        self.assertNotIn("\\kf", ass)

    def test_empty_range_raises(self):
        with self.assertRaises(ValueError):
            build_ass([Segment("x", 50, 55)], 0, 10)


@unittest.skipUnless(subprocess.run(["which", "ffmpeg"], capture_output=True).returncode == 0, "ffmpeg missing")
class Pipeline(unittest.TestCase):
    """REAL processing on a synthetic video (no mocks). Font via CLIPFORGE_TEST_FONT (default FreeSans)."""
    def test_render_validate(self):
        with tempfile.TemporaryDirectory() as d:
            src = str(Path(d) / "src.mp4")
            subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i", "testsrc2=size=1280x720:rate=30:duration=40",
                            "-f", "lavfi", "-i", "sine=frequency=440:duration=40", "-c:v", "libx264", "-c:a", "aac", "-shortest", src], check=True)
            words = tuple(Word(t, 6 + i * 0.6, 6.6 + i * 0.6) for i, t in enumerate((ML + " " + "Hello world").split()))
            seg = Segment("x", 6, 6 + 0.6 * len(words), words)
            clip = Clip("t", 5.0, 37.0)
            ass = build_ass([seg], clip.start, clip.end, CaptionStyle(font=os.environ.get("CLIPFORGE_TEST_FONT", "FreeSans")))
            self.assertEqual(validate_ass_timing(ass, clip.duration), [])
            ap = Path(d) / "c.ass"; ap.write_text(ass, encoding="utf-8")
            for layout in ("crop", "blur"):
                out = str(Path(d) / f"{layout}.mp4")
                render_clip(src, out, clip, RenderOptions(layout=layout, crop_center_x=0.3, preset="ultrafast"), str(ap))
                self.assertEqual(validate_output(out, 30, 60), [], layout)

    def test_validate_missing(self):
        self.assertEqual(validate_output("/nonexistent.mp4", 30, 60), ["output missing or empty"])


if __name__ == "__main__":
    unittest.main()
