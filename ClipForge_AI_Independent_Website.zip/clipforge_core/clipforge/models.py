from __future__ import annotations
from dataclasses import dataclass, field


@dataclass(frozen=True)
class Word:
    text: str
    start: float
    end: float


@dataclass(frozen=True)
class Segment:
    text: str
    start: float
    end: float
    words: tuple[Word, ...] = ()
    language: str | None = None


@dataclass
class Clip:
    title: str
    start: float
    end: float
    hook_summary: str = ""
    takeaway: str = ""
    rationale: str = ""
    language: str = ""
    score: float = 0.0
    opening_caption: str = ""

    @property
    def duration(self) -> float:
        return self.end - self.start


def segments_from_json(data: list[dict]) -> list[Segment]:
    """Parse provider-neutral transcript JSON: [{text,start,end,language?,words?:[{text,start,end}]}]."""
    out: list[Segment] = []
    for s in data:
        words = tuple(Word(w["text"], float(w["start"]), float(w["end"])) for w in s.get("words", []))
        seg = Segment(s["text"], float(s["start"]), float(s["end"]), words, s.get("language"))
        if seg.end <= seg.start:
            raise ValueError(f"Segment with non-positive duration at {seg.start}")
        out.append(seg)
    out.sort(key=lambda x: x.start)
    return out
