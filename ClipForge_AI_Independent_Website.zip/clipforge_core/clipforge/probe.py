"""FFprobe helpers and output validation. Subprocesses use argv lists (no shell)."""
from __future__ import annotations
import json, subprocess
from dataclasses import dataclass
from pathlib import Path


class ProbeError(RuntimeError): ...


@dataclass
class MediaInfo:
    duration: float
    width: int | None
    height: int | None
    fps: float | None
    has_audio: bool
    vcodec: str | None
    acodec: str | None


def probe(path: str | Path) -> MediaInfo:
    p = subprocess.run(["ffprobe", "-v", "error", "-print_format", "json", "-show_format", "-show_streams", str(path)],
                       capture_output=True, text=True, timeout=60)
    if p.returncode != 0:
        raise ProbeError(p.stderr.strip() or "ffprobe failed")
    d = json.loads(p.stdout)
    v = next((s for s in d.get("streams", []) if s["codec_type"] == "video"), None)
    a = next((s for s in d.get("streams", []) if s["codec_type"] == "audio"), None)
    fps = None
    if v and v.get("avg_frame_rate", "0/0") not in ("0/0", "0"):
        n, den = v["avg_frame_rate"].split("/"); fps = float(n) / float(den)
    return MediaInfo(float(d["format"].get("duration", 0)), v and v.get("width"), v and v.get("height"),
                     fps, a is not None, v and v.get("codec_name"), a and a.get("codec_name"))


def validate_output(path: str | Path, min_d: float, max_d: float, tolerance: float = 3.0,
                    size: tuple[int, int] = (1080, 1920)) -> list[str]:
    """Return a list of failures (empty = valid)."""
    path = Path(path)
    if not path.exists() or path.stat().st_size == 0:
        return ["output missing or empty"]
    try:
        m = probe(path)
    except ProbeError as e:
        return [f"unprobeable: {e}"]
    errs = []
    if (m.width, m.height) != size: errs.append(f"dimensions {m.width}x{m.height} != {size[0]}x{size[1]}")
    if m.vcodec != "h264": errs.append(f"video codec {m.vcodec} != h264")
    if not m.has_audio: errs.append("no audio stream")
    elif m.acodec != "aac": errs.append(f"audio codec {m.acodec} != aac")
    if not (min_d - tolerance <= m.duration <= max_d + tolerance): errs.append(f"duration {m.duration:.1f}s out of range")
    return errs
