"""Snap AI timestamps to transcript boundaries so clips never start/end mid-sentence."""
from __future__ import annotations
from .models import Segment, Clip


def snap_clip(clip: Clip, segments: list[Segment], source_duration: float, max_d: float = 60,
              pad_start: float = 0.15, pad_end: float = 0.35) -> Clip:
    if not segments:
        return clip
    # start: beginning of the segment containing/after clip.start
    first = next((s for s in segments if s.end > clip.start), segments[-1])
    start = first.start
    # end: end of the last segment that begins before clip.end
    last = [s for s in segments if s.start < clip.end][-1:] or [first]
    end = last[0].end
    # respect max duration by dropping trailing segments
    while end - start > max_d:
        earlier = [s for s in segments if start <= s.start and s.end < end]
        if not earlier:
            end = start + max_d
            break
        end = earlier[-1].end
    start = max(0.0, start - pad_start)
    end = min(source_duration, end + pad_end)
    return Clip(**{**clip.__dict__, "start": round(start, 3), "end": round(end, 3)})
