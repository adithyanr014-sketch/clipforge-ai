"""Validate LLM highlight JSON; deterministic fallback selector. Never invents content."""
from __future__ import annotations
import json, re
from .models import Clip, Segment

REQUIRED = ("title", "start", "end")


def _extract_json(raw: str):
    raw = raw.strip()
    raw = re.sub(r"^```(?:json)?\s*|\s*```$", "", raw)
    data = json.loads(raw)
    if isinstance(data, dict):
        data = data.get("clips", [])
    if not isinstance(data, list):
        raise ValueError("Expected a JSON list of clips")
    return data


def validate_highlights(raw: str, source_duration: float, min_d: float = 30, max_d: float = 60,
                        tolerance: float = 5, max_overlap: float = 0.2):
    """Return (accepted_clips, rejections[{index, reason}]). Raises ValueError/JSONDecodeError if unparseable."""
    accepted: list[Clip] = []
    rejected: list[dict] = []
    for i, c in enumerate(_extract_json(raw)):
        try:
            if not isinstance(c, dict) or any(k not in c for k in REQUIRED):
                raise ValueError("missing required fields")
            start, end = float(c["start"]), float(c["end"])
            if not (0 <= start < end <= source_duration + 0.01):
                raise ValueError(f"timestamps outside source (0..{source_duration:.1f}s)")
            d = end - start
            if not (min_d - tolerance <= d <= max_d + tolerance):
                raise ValueError(f"duration {d:.1f}s outside {min_d}-{max_d}s (±{tolerance}s)")
            clip = Clip(title=str(c["title"])[:120], start=start, end=end,
                        hook_summary=str(c.get("hook_summary", "")), takeaway=str(c.get("takeaway", "")),
                        rationale=str(c.get("rationale", "")), language=str(c.get("language", "")),
                        score=float(c.get("quality_score", 0)), opening_caption=str(c.get("opening_caption", "")))
            for o in accepted:
                ov = min(o.end, end) - max(o.start, start)
                if ov > max_overlap * min(o.duration, d):
                    raise ValueError(f"overlaps clip '{o.title}' by {ov:.1f}s")
            accepted.append(clip)
        except (ValueError, TypeError) as e:
            rejected.append({"index": i, "reason": str(e)})
    accepted.sort(key=lambda x: -x.score)
    return accepted, rejected


def fallback_select(segments: list[Segment], count: int = 5, min_d: float = 30, max_d: float = 60) -> list[Clip]:
    """Greedy, non-overlapping windows built from whole segments, ranked by speech density.
    Returns fewer than `count` clips if the transcript can't support them."""
    cands: list[Clip] = []
    for i in range(len(segments)):
        j = i
        while j < len(segments) and segments[j].end - segments[i].start <= max_d:
            j += 1
        j -= 1
        while j >= i and segments[j].end - segments[i].start >= min_d:
            win = segments[i:j + 1]
            dur = win[-1].end - win[0].start
            speech = sum(s.end - s.start for s in win)
            density = speech / dur
            ends_clean = win[-1].text.rstrip().endswith((".", "?", "!", "।"))
            cands.append(Clip(title=win[0].text[:60], start=win[0].start, end=win[-1].end,
                              rationale="Fallback: dense continuous speech ending on a sentence boundary",
                              score=round(density + (0.2 if ends_clean else 0), 3)))
            break
    cands.sort(key=lambda c: -c.score)
    picked: list[Clip] = []
    for c in cands:
        if all(c.end <= p.start or c.start >= p.end for p in picked):
            picked.append(c)
        if len(picked) == count:
            break
    return sorted(picked, key=lambda c: c.start)
