@echo off
setlocal
cd /d "%~dp0"
echo.
echo  ClipForge AI - local video studio
echo  ---------------------------------
where python >nul 2>nul
if errorlevel 1 (
  echo Python 3 was not found. Install Python 3.10 or newer first.
  pause
  exit /b 1
)
where ffmpeg >nul 2>nul
if errorlevel 1 (
  echo FFmpeg was not found. Install FFmpeg and add it to PATH.
  pause
  exit /b 1
)
if not exist .env (
  copy .env.example .env >nul
  echo Created .env from .env.example.
  echo Open .env in Notepad and add your OPENAI_API_KEY, then run this launcher again.
  start notepad .env
  pause
  exit /b 0
)
start "ClipForge browser" cmd /c "timeout /t 2 /nobreak ^>nul ^& start http://127.0.0.1:8000"
python server.py
pause
